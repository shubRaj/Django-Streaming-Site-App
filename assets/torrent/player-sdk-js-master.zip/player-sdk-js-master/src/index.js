import init from './webtor/WebtorGenerator';
window.webtor = init(window.webtor);